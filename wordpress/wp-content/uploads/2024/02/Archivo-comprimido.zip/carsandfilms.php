<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/stylez.css">
</head>
<body>
    <div class="tot">
        <div class="cap">
            <h1>carsandfilms</h1>
        </div>

        <div class="cos">
         <div class="coche" id="coche1">
            <p class="texto">Pulp Fiction</p>
         </div>
         <div class="coche" id="coche2">
            <p class="texto">Taxi Driver</p>
         </div>
         <div class="coche" id="coche3">
            <p class="texto">goldfinger</p>
         </div>
         <div class="coche" id="coche4">
            <p class="texto">Ghost Busters</p>
         </div>
         <div class="coche" id="coche5">
            <p class="texto">Mr. bean</p>
         </div>
         <div class="coche" id="coche6">
            <p class="texto">Back to the future</p>
         </div>
         <div class="coche" id="coche7">
            <p class="texto">Knight Rider</p>
         </div>
         <div class="coche" id="coche8">
            <p class="texto">The A-Team</p>
         </div>
         <div class="coche" id="coche9">
            <p class="texto">Breaking Bad</p>
         </div>
         </div>
        <div class="peu"></div>
    </div>     
</body>
</html>